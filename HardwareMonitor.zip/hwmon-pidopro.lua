-- hwmon-pidopro.lua
-- url request from the domoticz production server, to obtain hardware monitor data.
-- url http://domoticz-server-ip-address:8080/json.htm?type=devices&used=true
-- response is a JSON string containing all devices
-- select the required devices
-- 20190621 by rwbl

-- url of the pidopro web server
local URL_PIDOPRO = 'http://dopro-ip-address:8080/json.htm?type=devices&used=true';
-- callback of the url request - must be unique across all dzevents
local RES_PIDOPRO = 'hwmonpidopro';

-- define the idx of the dopro devices
-- these idx are used toobtain the values
local IDX_PIDOPRO_CPUTEMP = 4
local IDX_PIDOPRO_CPUUSAGE = 5
local IDX_PIDOPRO_RAMUSAGE = 1
local IDX_PIDOPRO_DISCUSAGE = 3

-- define the idx of the dodev devices showing the dopro data
-- these idx are used to update the values
local IDX_PIDOPROX_CPUTEMP = 43
local IDX_PIDOPROX_CPUUSAGE = 44
local IDX_PIDOPROX_RAMUSAGE = 45
local IDX_PIDOPROX_DISCUSAGE = 46

-- helper to round a number to n decimals
local DECIMALS = 1

function round(number, decimals)
    local power = 10^decimals
    return math.floor(number * power) / power
end

return {
	on = {
		timer = {
			-- 'every 5 minutes' 
			'every minute'
		},
		httpResponses = {
			RES_PIDOPRO -- must match with the callback passed to the openURL command
		}
	},
	execute = function(domoticz, item)

		if (item.isTimer) then
            -- request all devices data from the dopro server
			domoticz.openURL({
				url = URL_PIDOPRO,
				method = 'GET',
				callback = RES_PIDOPRO, -- see httpResponses above.
			})
		end

		if (item.isHTTPResponse) then
			if (item.statusCode == 200) then
				if (item.isJSON) then
                    local pcts = "";
                    local pct = 0;
                    local idx = 0;

				    -- get the result array from the json string ["result"] into a lua table
				    -- domoticz.log("***ITEMRESULT***")
					local itemResult = item.json.result

                    -- go over all entries, select the idx and its data
                    for i,v in ipairs(itemResult) do
                        idx = tonumber(v.idx);
                        -- domoticz.log(v.idx .. '=' .. idx);

                        -- Update Domoticz devices
                        if (idx == IDX_PIDOPRO_CPUTEMP) then
				            domoticz.devices(IDX_PIDOPROX_CPUTEMP).updateTemperature(round(v.Temp,DECIMALS));
                            -- domoticz.log(domoticz.devices(IDX_PIDOPROX_CPUTEMP).name .. '=' .. v.Temp);
                        end

                        if (idx == IDX_PIDOPRO_CPUUSAGE) then
                            pcts = string.gsub(v.Data,"%%","")
                            pct = tonumber(pcts)
        				    domoticz.devices(IDX_PIDOPROX_CPUUSAGE).updatePercentage(round(pct,DECIMALS))
                            -- domoticz.log(domoticz.devices(IDX_PIDOPROX_CPUUSAGE).name .. '=' .. tostring(pct))
                        end

                        if (idx == IDX_PIDOPRO_RAMUSAGE) then
                            pcts = string.gsub(v.Data,"%%","")
                            pct = tonumber(pcts)
        				    domoticz.devices(IDX_PIDOPROX_RAMUSAGE).updatePercentage(round(pct,DECIMALS))
                            -- domoticz.log(domoticz.devices(IDX_PIDOPROX_RAMUSAGE).name .. '=' .. tostring(pct))
                        end

                        if (idx == IDX_PIDOPRO_DISCUSAGE) then
                            pcts = string.gsub(v.Data,"%%","")
                            pct = tonumber(pcts)
        				    domoticz.devices(IDX_PIDOPROX_DISCUSAGE).updatePercentage(round(pct,DECIMALS))
                            -- domoticz.log(domoticz.devices(IDX_PIDOPROX_DISCUSAGE).name .. '=' .. tostring(pct))
                        end
                    end -- for loop
				end
			else
				domoticz.log('[ERROR] Problem handling the request:' .. item.statusText, domoticz.LOG_ERROR)
				-- domoticz.log(item, domoticz.LOG_ERROR)
			end
		end

	end
}
