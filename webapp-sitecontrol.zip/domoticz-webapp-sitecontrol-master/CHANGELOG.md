### 20200112

* NEW: First version published

### 20190101

* NEW: First ideas
