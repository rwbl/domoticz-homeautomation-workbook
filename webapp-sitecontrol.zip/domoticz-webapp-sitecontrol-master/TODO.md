### Status 20200112

#### NEW: Tab Favorites, Groups
Fast access to common used functions, i.e turn dedicated light On/Off, thermostat setpoint.

_Status_
Not started.

#### NEW: Tab Info, Goup Various
Show the Last message in a ui-text node.

_Status_
Not started.
