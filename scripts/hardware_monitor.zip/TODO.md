### Status 20190621
 
#### UPD: Check CPU usage top command
Seems the top command always returns 1.5% uage, i.e idle time 98.5%.
_Status_
Replaced by more complex /proc/stat command. Implemented but need to monitor.
