-- hwmon-pivz.lua
-- url request from the rpi volkszaehler, to obtain hardware monitor data.
-- url http://vz-ip-address:8061
-- response JSON string:
-- {"cpuusage":2,"cputemp":37.932,"discspaceused":16,"ramused":234,"ramfree":275,"ramusedpct":45.9725} 
-- 20190621 by rwbl

-- url of the pivz web server
local URL_PIVZ = 'http://vz-ip-address:8061'
-- callback of the url request - must be unique across all dzevents
local RES_PIVZ = 'hwmonpivz'

-- idx of the ivz devices with type, suntype info
local IDX_PIVZ_CPUTEMP = 38     -- temp, lacrosse
local IDX_PIVZ_CPUUSAGE = 40    -- general, percentage
local IDX_PIVZ_RAMUSAGE = 41    -- general, percentage
local IDX_PIVZ_DISCUSAGE = 42   -- general, percentage

-- helper to round a number to n decimals
local DECIMALS = 1

function round(number, decimals)
    local power = 10^decimals
    return math.floor(number * power) / power
end

return {
	on = {
		timer = {
		    -- Trigger the request
			'every minute'
			-- 'every 5 minutes'
		},
		httpResponses = {
			RES_PIVZ -- must match with the callback passed to the openURL command
		}
	},
	execute = function(domoticz, item)

        -- check the timer to place the url request
		if (item.isTimer) then
			domoticz.openURL({
				url = URL_PIVZ,
				method = 'GET',
				callback = RES_PIVZ, -- see httpResponses above.
			})
		end

        -- check if the item is a httpresponse from the openurl callback
		if (item.isHTTPResponse) then
			if (item.statusCode == 200) then
				if (item.isJSON) then
                    -- update the domoticz devices
				    domoticz.devices(IDX_PIVZ_CPUTEMP).updateTemperature(round(item.json.cputemp,DECIMALS))
				    domoticz.devices(IDX_PIVZ_CPUUSAGE).updatePercentage(round(item.json.cpuusage,DECIMALS))
				    domoticz.devices(IDX_PIVZ_RAMUSAGE).updatePercentage(round(item.json.ramusedpct,DECIMALS))
				    domoticz.devices(IDX_PIVZ_DISCUSAGE).updatePercentage(round(item.json.discspaceused,DECIMALS))

                    --[[
				    domoticz.log('CPU Temp C = ' .. item.json.cputemp)
				    domoticz.log('CPU Usage % = ' .. item.json.cpuusage)
				    domoticz.log('RAM Used % = ' .. item.json.ramusedpct)
				    domoticz.log('Disc Used % = ' .. item.json.discspaceused)
                    ]]--
                
				end
			else
				domoticz.log('[ERROR] Problem handling the request:' .. item.statusText, domoticz.LOG_ERROR)
				-- domoticz.log(item, domoticz.LOG_ERROR)
			end
		end

	end
}
