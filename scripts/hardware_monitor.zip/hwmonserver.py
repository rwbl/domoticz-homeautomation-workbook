#!/usr/bin/env python3

## hwmonserver.py
## execute hwmondata.sh to obtain system data, i.e. cpu temperature, disc space used etc. in JSON format.
## Sample JSON output bash scrpt: {"cpuusage":2,"cputemp":37.932,"discspaceused":16,"ramused":238,"ramfree":262,"ramusedpct":47.6}
## test with http://vz-ip-address:8061/
## Robert W.B. Linn, 20190619

import subprocess
import time
from http.server import HTTPServer
from http.server import BaseHTTPRequestHandler

PORT_NUMBER = 8061

SYSDATACOMMAND = '/home/pi/scripts/hwmondata.sh'

# Class to handle any incoming request from the web browser 
class requestHandler(BaseHTTPRequestHandler):
	
	# Handler for GET requests
	def do_GET(self):
		self.send_response(200)
        # Set the json content type and not 'text/html'.
        # This enables dzvents lua to parse json by checking the flag isJson
		self.send_header('Content-Type','application/json')
		self.end_headers()
        # Run the bash script and capture output and error
		command = SYSDATACOMMAND
		process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
		output, error = process.communicate()
        # The out contains the JSON string (see comments)
		# print(output)
		# If no error, then error contains None
		# print(error)
		# Send the html message
		self.wfile.write(output)
		return

try:
	# Create the web server and define the handler to manage incoming requests
	httpd = HTTPServer(('', PORT_NUMBER), requestHandler)
	print('Started web server on port ' , PORT_NUMBER)
	
	# Wait forever for incoming http requests
	httpd.serve_forever()

except KeyboardInterrupt:
	print('^C received, shutting down the web server')
	httpd.socket.close()
