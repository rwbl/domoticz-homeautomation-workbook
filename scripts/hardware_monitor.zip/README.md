# Hardware Monitor
Function from the workbook on how to build a Domoticz Home Automation System on a Raspberry Pi.

## Purpose
To monitor hardware data for the Raspberry Pi (RPi) devices used in this Home Automation Solution.
__RPi Data Monitored__
CPU Usage %, CPU Temperature °C, Discspace Used %, RAM Used %.

__RPi Devices (Name)__
Domoticz Production (pidopro), Domoticz Development (pidodev), volkszaehler (pivz), homematic (pihm - planned).

The hardware data for all the RPi's is displayed in the Domoticz Development Server.

_Note_
The source code of the scripts shared might change. Check out the script source code files.

## Solution
The data provided by each RPi: CPU Temp, CPU Usage, RAM Usage, Disc Usage.

For the RPi's running a Domoticz instance, data from the hardware "Motherboard Sensors" is used.
The devices are named as mentioned, added to the Domoticz instance roomplan "Hardware Monitor" which is used as a dashboard on that instance including a floorplan.

For the other RPI's, a webserver solution "hwmon" is used to gather the hardware data.

The Domoticz Development Device:
* has 4 virtual sensor devices (device name data) for each of the RPi's, i.e. pivz CPU Temp, pivz CPU Usage etc.
* has a roomplan "Hardware Monitor" with all the hardware monitor devices
* has a flooplan "Hardware Monitor" using the roomplan "Hardware Monitor"
* gathers the data in regular intervals via dzVents Lua scripts (one for each RPi), i.e. hwmon-pivz.lua, hwmon-pidopro.lua
* displays the data in the dashboard and floorplan

__Node-RED__
Tested various Node-RED flows for pivz data.
* Simple flow with a HTTP request node, triggered every 5 minutes by an Inject node, gathers the data and logs.
* Dashboard UI more complex flow with gauges and charts grouped by data property.

## Solution hwmon
This solution consists out of a mix of scripts:
1. Bash script, hwmondata.sh, gets the data and outputs a JSON string. This script can be run from the CLI or via webserver request.
2. Python3 webserver, hwmonserver.py, running as a service, hwmon.service, returns the JSON string on HTTP request by running the as script.
3. Domoticz: dzVents Lua script opens the HTTP request url and parses the HTTP response JSON string into Domoticz Virtual Sensors devices.

The files hwmondata.sh, hwmonserver.py, hwmon.service are located in folder /home/pi/scripts.
Included are also tmp files generated.

Example of the JSON string returned by the bash script, which is called by the webserver and parsed by the dzVents Lua script to update the Domoticz devices:
```
{"cpuusage":2,"cputemp":37.394,"discspaceused":16,"ramused":234,"ramfree":274,"ramusedpct":46.063} 
```

### Bash Script hwmondata.sh
_Note_
Prior starting first time, ensure to create two temp files with a 0 as content: cpuprevtotal.tmp and cpurprevidle.tmp (or copy the files from the archive hwmon.zip).

```
#!/bin/bash

## hwmondata.sh
## Run various rpi commands to obtain hardware data.
## Example output:
## {"cpuusage":2,"cputemp":37.394,"discspaceused":16,"ramused":234,"ramfree":274,"ramusedpct":46.063} 
## Ensure:
## To make the script executable: sudo chmod +x hwmondata.sh
## To copy the files cpuprevtotal.tmp and cpuprevidle.tmp to the same folder as hwmondata.sh
## Test: .\hwmondata.sh
## 20200318 rwbl

# Set the scripts folder
cd /home/pi/scripts

# Run the commands

# CPU Usage %
## Command /proc/stat
## CPU Usage Calculate NN% 
## cpuusage=$(grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print usage }')

## Command /proc/stat with vars
## CPU Usage Calculate NN%
## based on script from Paul Colby (http://colby.id.au), no rights reserved ;)

## create a variable to represent the filename
## for the first time ensure to init with 0
PREV_TOTAL_FILE="/home/pi/scripts/cpuprevtotal.tmp"
PREV_IDLE_FILE="/home/pi/scripts/cpuprevidle.tmp"
PREV_TOTAL=$(<$PREV_TOTAL_FILE)
PREV_IDLE=$(<$PREV_IDLE_FILE)

## Get the total CPU statistics, discarding the 'cpu ' prefix.
CPU=(`sed -n 's/^cpu\s//p' /proc/stat`)
IDLE=${CPU[3]} # Just the idle CPU time.

## Calculate the total CPU time.
TOTAL=0
for VALUE in "${CPU[@]}"; do
  let "TOTAL=$TOTAL+$VALUE"
done

## Calculate the CPU usage since we last checked.
let "DIFF_IDLE=$IDLE-$PREV_IDLE"
let "DIFF_TOTAL=$TOTAL-$PREV_TOTAL"
let "DIFF_USAGE=(1000*($DIFF_TOTAL-$DIFF_IDLE)/$DIFF_TOTAL+5)/10"
## echo -en "\rCPU: $DIFF_USAGE%  \b\b"
cpuusage="$DIFF_USAGE"
# echo "$cpuusage"

## Remember the total and idle CPU times for the next check.
PREV_TOTAL="$TOTAL"
PREV_IDLE="$IDLE"
echo "$PREV_TOTAL" > ${PREV_TOTAL_FILE}
echo "$PREV_IDLE" > ${PREV_IDLE_FILE}

# CPU
# CPU Temperature °C - divide by 1000 
cputemp=$(cat /sys/class/thermal/thermal_zone0/temp)
cputemp=$(awk "BEGIN  {print $cputemp/1000}")

# DISC
# Disc Space used NN%
discspaceused=$(df -H | grep 'root' | awk '{ print $5 }')
# Remove the % char
discspaceused=${discspaceused//%/}
# echo "${discspaceused}"

# RAM
## Note: Raspbian Buster 'free -h' reports memory in "Mi" units, as opposed to "M".
## ramfree=$(free -h | head -n2 | tail -n1 | awk '{print $4}' | tr -d [=M=])
## Workaround: -> in 'tr -d', filter out all alphabetical characters, not just M
## ramfree=$(free -h | head -n2 | tail -n1 | awk '{print $4}' | tr -d [:alpha:])
# RAM free
ramfree=$(free -h | head -n2 | tail -n1 | awk '{print $4}' | tr -d [:alpha:])
# RAM used
ramused=$(free -h | head -n2 | tail -n1 | awk '{print $3}' | tr -d [:alpha:])
ramusedpct=$(awk "BEGIN {print $ramused/($ramused+$ramfree)*100}")

# OUTPUT
# Output the JSON string
echo "{\"cpuusage\":$cpuusage,\"cputemp\":$cputemp,\"discspaceused\":$discspaceused,\"ramused\":$ramused,\"ramfree\":$ramfree,\"ramusedpct\":$ramusedpct}"
```

### Webserver hwmonserver.py
```
#!/usr/bin/env python3

## hwmonserver.py
## execute hwmondata.sh to obtain system data, i.e. cpu temperature, disc space used etc. in JSON format.
## Sample JSON output bash scrpt: {"cpuusage":2,"cputemp":37.932,"discspaceused":16,"ramused":238,"ramfree":262,"ramusedpct":47.6}
## test with http://vz-ip-address:8061/
## Robert W.B. Linn, 20190619

import subprocess
import time
from http.server import HTTPServer
from http.server import BaseHTTPRequestHandler

PORT_NUMBER = 8061

SYSDATACOMMAND = '/home/pi/scripts/hwmondata.sh'

# Class to handle any incoming request from the web browser 
class requestHandler(BaseHTTPRequestHandler):
	
	# Handler for GET requests
	def do_GET(self):
		self.send_response(200)
        # Set the json content type and not 'text/html'.
        # This enables dzvents lua to parse json by checking the flag isJson
		self.send_header('Content-Type','application/json')
		self.end_headers()
        # Run the bash script and capture output and error
		command = SYSDATACOMMAND
		process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
		output, error = process.communicate()
        # The out contains the JSON string (see comments)
		# print(output)
		# If no error, then error contains None
		# print(error)
		# Send the html message
		self.wfile.write(output)
		return

try:
	# Create the web server and define the handler to manage incoming requests
	httpd = HTTPServer(('', PORT_NUMBER), requestHandler)
	print('Started web server on port ' , PORT_NUMBER)
	
	# Wait forever for incoming http requests
	httpd.serve_forever()

except KeyboardInterrupt:
	print('^C received, shutting down the web server')
	httpd.socket.close()
```

### Service hwmon.service
(See [Reference](https://www.raspberrypi.org/documentation/linux/usage/systemd.md)
Login as user Pi.
cd scripts
Create the service file
nano hwmon.service
Content:
```
[Unit]
Description=Hardware Monitor Service
After=network.target

[Service]
ExecStart=/usr/bin/python3 -u hwmonserver.py
WorkingDirectory=/home/pi/scripts
StandardOutput=inherit
StandardError=inherit
Restart=always
User=pi

[Install]
WantedBy=multi-user.target
```

Copy the service file to the systemd folder
```
sudo cp hwmon.service /etc/systemd/system/hwmon.service
```

### Start the service
```
sudo systemctl start hwmon.service
```

### Check if the service is running
```
ps ax | grep hwmonserver
```
 2299 ?        Ss     0:00 /usr/bin/python3 -u hwmonserver.py

### Stop the service
```
sudo systemctl stop hwmon.service
```

and check again if the service has stopped = nothing to be retuned from the command.

### Start Service at Boot
Start automatically on reboot:
```
sudo systemctl enable hwmon.service
```
The systemctl command can also be used to restart the service or to disable.
Example with output:
```
sudo systemctl enable hwmon.service
Created symlink /etc/systemd/system/multi-user.target.wants/hwmon.service → /etc/systemd/system/hwmon.service.
```

### Issues
If there are issues to copy the service file after a change, ensure
1. to stop the server: sudo systemctl stop hwmon.service
2. reload the deamon: sudo systemctl daemon-reload

### Domoticz dzVents Lua script (hwmon-pivz.lua)
```
-- hwmon-pivz.lua
-- url request from the rpi volkszaehler, to obtain hardware monitor data.
-- url http://vz-ip-address:8061
-- response JSON string:
-- {"cpuusage":2,"cputemp":37.932,"discspaceused":16,"ramused":234,"ramfree":275,"ramusedpct":45.9725} 
-- 20190621 by rwbl

-- url of the pivz web server
local URL_PIVZ = 'http://vz-ip-address:8061'
-- callback of the url request - must be unique across all dzevents
local RES_PIVZ = 'hwmonpivz'

-- idx of the ivz devices with type, suntype info
local IDX_PIVZ_CPUTEMP = 38     -- temp, lacrosse
local IDX_PIVZ_CPUUSAGE = 40    -- general, percentage
local IDX_PIVZ_RAMUSAGE = 41    -- general, percentage
local IDX_PIVZ_DISCUSAGE = 42   -- general, percentage

-- helper to round a number to n decimals
function round(number, decimals)
    local power = 10^decimals
    return math.floor(number * power) / power
end

return {
	on = {
		timer = {
		    -- Trigger the request
			'every minute'
			-- 'every 5 minutes'
		},
		httpResponses = {
			RES_PIVZ -- must match with the callback passed to the openURL command
		}
	},
	execute = function(domoticz, item)

        -- check the timer to place the url request
		if (item.isTimer) then
			domoticz.openURL({
				url = URL_PIVZ,
				method = 'GET',
				callback = RES_PIVZ, -- see httpResponses above.
			})
		end

        -- check if the item is a httpresponse from the openurl callback
		if (item.isHTTPResponse) then
			if (item.statusCode == 200) then
				if (item.isJSON) then
                    -- update the domoticz devices
				    domoticz.devices(IDX_PIVZ_CPUTEMP).updateTemperature(round(item.json.cputemp,2))
				    domoticz.devices(IDX_PIVZ_CPUUSAGE).updatePercentage(round(item.json.cpuusage,2))
				    domoticz.devices(IDX_PIVZ_RAMUSAGE).updatePercentage(round(item.json.ramusedpct,2))
				    domoticz.devices(IDX_PIVZ_DISCUSAGE).updatePercentage(round(item.json.discspaceused,2))

                    --[[
				    domoticz.log('CPU Temp C = ' .. item.json.cputemp)
				    domoticz.log('CPU Usage % = ' .. item.json.cpuusage)
				    domoticz.log('RAM Used % = ' .. item.json.ramusedpct)
				    domoticz.log('Disc Used % = ' .. item.json.discspaceused)
                    ]]--
                
				end
			else
				domoticz.log('[ERROR] Problem handling the request:' .. item.statusText, domoticz.LOG_ERROR)
				-- domoticz.log(item, domoticz.LOG_ERROR)
			end
		end

	end
}
```

### Domoticz Log Example
The script is started.
The HTTP request is triggered with an unique callback!
Wait for the HTTP request to complete.
Handle the HTTP response event.
Start the script again with the HTTP response.

```
2019-06-19 09:30:00.542 Status: dzVents: Info: ------ Start internal script: hwmon-rpi-vz:, trigger: every minute 
2019-06-19 09:30:00.542 Status: dzVents: Info: ------ Finished hwmon-rpi-vz 
```
```
2019-06-19 09:30:01.138 Status: dzVents: Info: Handling httpResponse-events for: "hwmonrpivz 
2019-06-19 09:30:01.138 Status: dzVents: Info: ------ Start internal script: hwmon-rpi-vz: HTTPResponse: "hwmonrpivz" 
2019-06-19 09:30:01.144 Status: dzVents: Info: CPU Usage % = 1.5 
2019-06-19 09:30:01.144 Status: dzVents: Info: CPU Temp C = 37.932 
2019-06-19 09:30:01.144 Status: dzVents: Info: Disc Used % = 16 
2019-06-19 09:30:01.144 Status: dzVents: Info: RAM Used % = 46.063 
2019-06-19 09:30:01.163 Status: dzVents: Info: ------ Finished hwmon-rpi-vz 
```

## Solution pidopro
A dzvents Lua script gathers all used devices data from which the hardware monitor devices (4) is selected to update the devices on the Domoticz Development server.

### Domoticz dzVents Lua script (hwmon-pidopro.lua)
```
-- hwmon-pidopro.lua
-- url request from the domoticz production server, to obtain hardware monitor data.
-- url http://domoticz-server-ip-address:8080/json.htm?type=devices&used=true
-- response is a JSON string containing all devices
-- select the required devices
-- 20190621 by rwbl

-- url of the pidopro web server
local URL_PIDOPRO = 'http://dopro-ip-address:8080/json.htm?type=devices&used=true';
-- callback of the url request - must be unique across all dzevents
local RES_PIDOPRO = 'hwmonpidopro';

-- define the idx of the dopro devices
-- these idx are used toobtain the values
local IDX_PIDOPRO_CPUTEMP = 4
local IDX_PIDOPRO_CPUUSAGE = 5
local IDX_PIDOPRO_RAMUSAGE = 1
local IDX_PIDOPRO_DISCUSAGE = 3

-- define the idx of the dodev devices showing the dopro data
-- these idx are used to update the values
local IDX_PIDOPROX_CPUTEMP = 43
local IDX_PIDOPROX_CPUUSAGE = 44
local IDX_PIDOPROX_RAMUSAGE = 45
local IDX_PIDOPROX_DISCUSAGE = 46

return {
	on = {
		timer = {
			-- 'every 5 minutes' 
			'every minute'
		},
		httpResponses = {
			RES_PIDOPRO -- must match with the callback passed to the openURL command
		}
	},
	execute = function(domoticz, item)

		if (item.isTimer) then
            -- request all devices data from the dopro server
			domoticz.openURL({
				url = URL_PIDOPRO,
				method = 'GET',
				callback = RES_PIDOPRO, -- see httpResponses above.
			})
		end

		if (item.isHTTPResponse) then
			if (item.statusCode == 200) then
				if (item.isJSON) then
                    local pcts = "";
                    local pct = 0;
                    local idx = 0;

				    -- get the result array from the json string ["result"] into a lua table
				    -- domoticz.log("***ITEMRESULT***")
					local itemResult = item.json.result

                    -- go over all entries, select the idx and its data
                    for i,v in ipairs(itemResult) do
                        idx = tonumber(v.idx);
                        -- domoticz.log(v.idx .. '=' .. idx);

                        -- Update Domoticz devices
                        if (idx == IDX_PIDOPRO_CPUTEMP) then
				            domoticz.devices(IDX_PIDOPROX_CPUTEMP).updateTemperature(v.Temp);
                            -- domoticz.log(domoticz.devices(IDX_PIDOPROX_CPUTEMP).name .. '=' .. v.Temp);
                        end

                        if (idx == IDX_PIDOPRO_CPUUSAGE) then
                            pcts = string.gsub(v.Data,"%%","")
                            pct = tonumber(pcts)
        				    domoticz.devices(IDX_PIDOPROX_CPUUSAGE).updatePercentage(pct)
                            -- domoticz.log(domoticz.devices(IDX_PIDOPROX_CPUUSAGE).name .. '=' .. tostring(pct))
                        end

                        if (idx == IDX_PIDOPRO_RAMUSAGE) then
                            pcts = string.gsub(v.Data,"%%","")
                            pct = tonumber(pcts)
        				    domoticz.devices(IDX_PIDOPROX_RAMUSAGE).updatePercentage(pct)
                            -- domoticz.log(domoticz.devices(IDX_PIDOPROX_RAMUSAGE).name .. '=' .. tostring(pct))
                        end

                        if (idx == IDX_PIDOPRO_DISCUSAGE) then
                            pcts = string.gsub(v.Data,"%%","")
                            pct = tonumber(pcts)
        				    domoticz.devices(IDX_PIDOPROX_DISCUSAGE).updatePercentage(pct)
                            -- domoticz.log(domoticz.devices(IDX_PIDOPROX_DISCUSAGE).name .. '=' .. tostring(pct))
                        end
                    end -- for loop
				end
			else
				domoticz.log('[ERROR] Problem handling the request:' .. item.statusText, domoticz.LOG_ERROR)
				-- domoticz.log(item, domoticz.LOG_ERROR)
			end
		end

	end
}
```

## ToDo
See TODO.md
