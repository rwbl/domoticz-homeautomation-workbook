#!/bin/bash

## hwmondata.sh
## Run various rpi commands to obtain hardware data.
## Example output:
## {"cpuusage":2,"cputemp":37.394,"discspaceused":16,"ramused":234,"ramfree":274,"ramusedpct":46.063} 
## Ensure:
## To make the script executable: sudo chmod +x hwmondata.sh
## To copy the files cpuprevtotal.tmp and cpuprevidle.tmp to the same folder as hwmondata.sh
## Test: .\hwmondata.sh
## 20200318 rwbl

# Set the scripts folder
cd /home/pi/scripts

# Run the commands

# CPU Usage %
## Command /proc/stat
## CPU Usage Calculate NN% 
## cpuusage=$(grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print usage }')

## Command /proc/stat with vars
## CPU Usage Calculate NN%
## based on script from Paul Colby (http://colby.id.au), no rights reserved ;)

## create a variable to represent the filename
## for the first time ensure to init with 0
PREV_TOTAL_FILE="/home/pi/scripts/cpuprevtotal.tmp"
PREV_IDLE_FILE="/home/pi/scripts/cpuprevidle.tmp"
PREV_TOTAL=$(<$PREV_TOTAL_FILE)
PREV_IDLE=$(<$PREV_IDLE_FILE)

## Get the total CPU statistics, discarding the 'cpu ' prefix.
CPU=(`sed -n 's/^cpu\s//p' /proc/stat`)
IDLE=${CPU[3]} # Just the idle CPU time.

## Calculate the total CPU time.
TOTAL=0
for VALUE in "${CPU[@]}"; do
  let "TOTAL=$TOTAL+$VALUE"
done

## Calculate the CPU usage since we last checked.
let "DIFF_IDLE=$IDLE-$PREV_IDLE"
let "DIFF_TOTAL=$TOTAL-$PREV_TOTAL"
let "DIFF_USAGE=(1000*($DIFF_TOTAL-$DIFF_IDLE)/$DIFF_TOTAL+5)/10"
## echo -en "\rCPU: $DIFF_USAGE%  \b\b"
cpuusage="$DIFF_USAGE"
# echo "$cpuusage"

## Remember the total and idle CPU times for the next check.
PREV_TOTAL="$TOTAL"
PREV_IDLE="$IDLE"
echo "$PREV_TOTAL" > ${PREV_TOTAL_FILE}
echo "$PREV_IDLE" > ${PREV_IDLE_FILE}

# CPU
# CPU Temperature °C - divide by 1000 
cputemp=$(cat /sys/class/thermal/thermal_zone0/temp)
cputemp=$(awk "BEGIN  {print $cputemp/1000}")

# DISC
# Disc Space used NN%
discspaceused=$(df -H | grep 'root' | awk '{ print $5 }')
# Remove the % char
discspaceused=${discspaceused//%/}
# echo "${discspaceused}"

# RAM
## Note: Raspbian Buster 'free -h' reports memory in "Mi" units, as opposed to "M".
## ramfree=$(free -h | head -n2 | tail -n1 | awk '{print $4}' | tr -d [=M=])
## Workaround: -> in 'tr -d', filter out all alphabetical characters, not just M
## ramfree=$(free -h | head -n2 | tail -n1 | awk '{print $4}' | tr -d [:alpha:])
# RAM free
ramfree=$(free -h | head -n2 | tail -n1 | awk '{print $4}' | tr -d [:alpha:])
# RAM used
ramused=$(free -h | head -n2 | tail -n1 | awk '{print $3}' | tr -d [:alpha:])
ramusedpct=$(awk "BEGIN {print $ramused/($ramused+$ramfree)*100}")

# OUTPUT
# Output the JSON string
echo "{\"cpuusage\":$cpuusage,\"cputemp\":$cputemp,\"discspaceused\":$discspaceused,\"ramused\":$ramused,\"ramfree\":$ramfree,\"ramusedpct\":$ramusedpct}"
