## Domoticz Plugin Radiator Thermostat HmIP-eTRV-B & HmIP-eTRV-B

### v1.2.0 (Build 20191222)
* NEW: Valve position device using datapoint LEVEL
* NEW: Sync setpoint between CCU and Domoticz if changed by the CCU
* UPD: Error handling xpath device value length 
* UPD: Various minor improvements

### v1.0.0 (Build 20191214)
* NEW: Plugin with Domoticz devices [Name (Type,SubType) Setpoint (Thermostat,Setpoint), Temperature (Temp,LaCrosse TX3), Battery (General,Alert)
