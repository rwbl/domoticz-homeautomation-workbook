# ToDo domoticz-plugin-tinkerforge-lcd20x4

### NEW: Handle Disconnect
Improve handling master brick or bricklet disconnect.

__Status__
Not started
  
