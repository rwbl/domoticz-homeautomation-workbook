# ToDo domoticz-plugin-tinkerforge-lcd20x4

### v1.0.0 (Build 20200215)
* NEW: First version published.
