# Changelog domoticz-plugin-tinkerforge-lcd20x4-lite

### v1.0.0 (Build 20200214)
* NEW: First version published.
