# ToDo domoticz-plugin-tinkerforge-lcd20x4-lite

### NEW: Buttons
Enable to use te 4 buttons.

__Status__
Not started
  
