### v1.0.2 (Build 20191222)
* UPD: HTTP request URL replaced /config/ by /addons/.

### v1.0.1 (Build 20190706)
* UPD: Plugin definition enhanced; Changed error messages do domoticz.error.

### v1.0.0 (Build 20190702)
* NEW: First version published.
