# Changelog domoticz-plugin-tinkerforge-trafficlight

### v1.2.0 (Build 20200216)
* UPD: Various minor improvements, i.e. defined units as constants, errors logged to error log instead status, enhanced plugin text
* UPD: Readme to explain more the concept

### v1.1.0 (Build 20190604)
* UPD: Improved error handling

### v1.0.1 (Build 20190528)
* UPD: Changed parameter "Mode1" to handle more than one UID (=Tinkerforge Bricklet)
* UPD: Improved error handling

### v1.0.0 (Build 20190527)
* NEW: First version published
