# ToDo domoticz-plugin-tinkerforge-trafficlight
Status 20200216

### UPD: Improve Error Handling
Improve error handling in case of wrong IP address or UID or Master Brick disconnected.

_Status_
Not started.

