# Changelog domoticz-plugin-tinkerforge-gbledv2

### v1.0.0 (Build 20200206)
* NEW: First version published.
