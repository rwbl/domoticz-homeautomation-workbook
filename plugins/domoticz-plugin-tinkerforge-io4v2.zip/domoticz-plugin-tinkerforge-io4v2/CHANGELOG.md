# Changelog domoticz-plugin-tinkerforge-io4v2

### v1.0.0 (Build 20200204)
* NEW: First version published.
