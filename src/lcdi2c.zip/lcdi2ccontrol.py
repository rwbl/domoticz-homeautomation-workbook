#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File:
lcdi2ccontrol.py
Project:
Domoticz-Home-Automation-Workbook
Purpose:
Setter Example = Setting the text and/or configuration of a I2C LCD 2004 Display.
Description:
JSON formatted string as argument with following key:value pairs:
IMPORTANT: all keys must be in lowercase.
"address":"String"  - Address of the LCD. Default: "0x27" (optional)
"backlight":0|1     - Set backlight off|on
"cursor":0|1        - Set cursor off|on
"blinking":0|1      - Set blink cursor off|on
"clear":0|1         - Leave or clear display 
"debug":0|1         - Log to the console off|on
"lcdlines":[
    {"line":1,"position":1,"clear":1,"text":"Text 1"},
    {"line":2,"position":1,"clear":1,"text":"Text 2"},
    {"line":3,"position":1,"clear":1,"text":"Text 3"},
    {"line":4,"position":1,"clear":1,"text":"Text 4"}
]

The LCDLINES JSON array has 1 to N entries with line properties.
It is possible to define an entry for a line or multiple entries for a line for different positions.
JSON keys in lowercase with value explain:
"line":1-4      - Line numbers 1 to 4 (optional, default 1) (internal the lcd uses lines 0-3 but for ease of use the lines are set between 1-4)
"position":1-20 - Columns 1 to 20 (optional, default 1) 
"clear":0|1|2   - Clear display (optional, default 0): 0=no clear, 1=clear line, 2=clear display
"text":"TEXT"   - Text to display at the line (mandatory) 

Examples:
Set text line 1 & 2:
    cd domoticz/scripts/python
    python3 lcdi2ccontrol.py '{"address":"0x27", "clear":1, "lcdlines":[{"line":1,"position":1,"clear":1,"text":"Text"},{"line":2,"position":1,"clear":1,"text":"Text2"}]}'
    python3 lcdi2ccontrol.py '{"clear":0, "lcdlines":[{"line":1,"position":1,"clear":1,"text":"Hello"},{"line":4,"position":1,"clear":1,"text":"World!"}]}'
Result:
    {"status": "OK", "title": "Lines written #2"}

Set text lines 1,2,3,4:     
    python3 lcdi2ccontrol.py '{"address":"0x27", "lcdlines":[{"line":1,"position":1,"clear":1,"text":"Text 1"},{"line":2,"position":1,"clear":1,"text":"Text 2"},{"line":3,"position":1,"clear":1,"text":"Text 3"},{"line":4,"position":1,"clear":1,"text":"Text 4"}]}'

Set Backlight Off using default address 0x27:
    python3 /home/pi/domoticz/scripts/python/lcdi2ccontrol.py '{"backlight":0}'
Result:
    {"status": "OK", "title": "Set Configuration."}

Write special character:
    # in this example special char with index 0 (the battery, see file lcdi2ccustomchar.json) is displayed
    python3 lcdi2ccontrol.py '{"lcdlines":[{"line":1,"position":5,"clear":1,"text":"Hello"},{"line":4,"position":10,"clear":1,"text":"World = \u0000"}]}'

Debug on:
 python3 lcdi2ccontrol.py '{"debug":1, "lcdlines":[{"line":1,"position":5,"text":"He
llo"},{"line":3,"position":10,"clear":1,"text":"World"}]}'
DEBUG::JSON:A=0x27,B=1,C=0,BL=0,CL=1,L=[{'line': 1, 'position': 5, 'text': 'Hello'}, {'line': 3, 'position': 10, 'clear': 1, 'text': 'World'}]
DEBUG::Creating LCD Object:A=0x27,L=4,C=20,CL=1
DEBUG::Creating LCD Object = done
DEBUG::LCD clear = done
DEBUG::set_configuration: B=1,C=0,BL=0,CL=1
DEBUG::cursor: 0 = done
DEBUG::blinking: 0 = done
DEBUG::clear: 1 = done
DEBUG::Customchar: #characters defined: 7
DEBUG::Customchar: 0,battery,[14, 27, 17, 17, 17, 17, 17, 31]
DEBUG::Customchar: Index=0,Name=battery,Char=14,27,17,17,17,17,17,31
DEBUG::Customchar: 1,clock,[31, 17, 10, 4, 14, 31, 31, 0]
DEBUG::Customchar: Index=1,Name=clock,Char=31,17,10,4,14,31,31,0
DEBUG::Customchar: 2,arrowdown,[0, 4, 4, 4, 31, 14, 4, 0]
DEBUG::Customchar: Index=2,Name=arrowdown,Char=0,4,4,4,31,14,4,0
DEBUG::Customchar: 3,arrowup,[0, 4, 14, 31, 4, 4, 4, 0]
DEBUG::Customchar: Index=3,Name=arrowup,Char=0,4,14,31,4,4,4,0
DEBUG::Customchar: 4,nochange,[0, 0, 31, 0, 31, 0, 0, 0]
DEBUG::Customchar: Index=4,Name=nochange,Char=0,0,31,0,31,0,0,0
DEBUG::Customchar: 5,smiley,[0, 0, 10, 0, 0, 17, 14, 0]
DEBUG::Customchar: Index=5,Name=smiley,Char=0,0,10,0,0,17,14,0
DEBUG::Customchar: 6,speaker,[1, 7, 15, 31, 31, 15, 7, 1]
DEBUG::Customchar: Index=6,Name=speaker,Char=1,7,15,31,31,15,7,1
DEBUG::Customchar = done
DEBUG::backlight: 1 = done
DEBUG::set_configuration = done
DEBUG::set_configuration result: {'status': 'OK', 'title': 'Set Configuration.'}
DEBUG::write_lines: text: [{'line': 1, 'position': 5, 'text': 'Hello'}, {'line': 3, 'position': 10, 'clear': 1, 'text': 'World'}]
DEBUG::write_lines: parsing json ...
DEBUG::write_lines: #lines: 2
DEBUG::Line:1
DEBUG::line: items (l,p,t,c) 1,5,Hello,0
DEBUG::write_lines: L=0,P=4,T=Hello
DEBUG::Line:3
DEBUG::line: items (l,p,t,c) 3,10,World,1
DEBUG::write_lines: L=2,P=9,T=World
{"status": "OK", "title": "Lines written #2"}

20200804 rwbL
"""

import lcdi2clib
from datetime import datetime
from time import sleep
import sys
import os
import os.path
import json

## Keys for the display argument JSON format
KEYADDRESS = "address"      # Address of the LCD. Default: "0x27" (optional)
KEYBACKLIGHT = "backlight"  # 0|1 - Set backlight off|on
KEYCURSOR = "cursor"        # 0|1 - Set cursor off|on
KEYBLINKING = "blinking"    # 0|1 - Set blink cursor off|on
KEYCLEAR = "clear"           # 0|1 - Leave or clear display 
KEYDEBUG = "debug"          # 0|1 - Log to the console off|on
KEYLCDLINES = "lcdlines"    # [{}]

## Set defaults
DEBUG = 0           # no debug
ADDRESS = "0x27"    # default lcd2004
BACKLIGHT = 1       # set backlight on
CURSOR = 0
BLINKING = 0
CLEAR = 1           # clear the display prior writing lines
LCDLINES = None     # no lines to enable using config settings only
LINES = 4           # default I2C LCD 2004 display
COLS = 20           # default I2C LCD 2004 display

# Custom Characters file JSON array format - located in the same folder as this python script
CUSTOMCHARFILE = os.getcwd() + "/scripts/python/lcdi2ccustomchar.json"
# CUSTOMCHARFILE = "/home/pi/domoticz/scripts/python/lcdi2ccustomchar.json"

# Status
STATUSOK = "OK"
STATUSERROR = "ERROR"

# Messages (not all)
MSGERRSETCONFIG = "[ERROR] Set configuration failed. Check settings."

# Arguments Length
ARGVLEN = 2

"""
Log to the console
"""
def log(str):
    if DEBUG == 1:
        print("DEBUG::" + str)

"""
Set the lcd configuration
Parameter:
lcd - LCD object
backlight - 0|1 : set backlight off|on
cursor - 0|1 : set cursor off|on
blink - 0|1 : set blink cursor off|on
clear - 0|1 : leave or clear display 
"""
def set_configuration(lcd,backlight,cursor,blinking,clear):
    log("set_configuration: B={},C={},BL={},CL={}".format(backlight,cursor,blinking,clear))
    status = STATUSOK
    title = ""
    try:
        # Set backlight,cursor,blinking,clear
        if cursor == 1:
            lcd.cursor_on()
        else:
            lcd.cursor_off()
        log("cursor: {} = done".format(cursor))
        #sleep(0.1)
        if blinking == 1:
            lcd.cursor_blink()
        log("blinking: {} = done".format(blinking))
        #sleep(0.1)
        if clear == 1:
            lcd.clear()
        log("clear: {} = done".format(clear))
        
        # Set Custom Characters with index 0-7 as max 8 custom characters can be defined.
        # dzVents Lua scripts:
        # The \ character needs to be escaped, i.e. line = string.format(line, l, p, "\\u0008", domoticz.helpers.isnowhhmm(domoticz) )
        # Ensure to write in unicode \u00NN and NOT \xNN - Example: lcdDev.write_line(0, 0, "Battery: " + "\u0008")
        # JSON has no hex escape \xNN but supports unicode escape \uNNNN
        # 
        # Example custom character definition and write to the lcd:
        #     battery = [14,27,17,17,17,17,17,31] 
        #     clock = [31,17,10,4,14,31,31,0]
        #     lcdDev.set_custom_character(0, clock)
        # 
        # JSON File
        # Read the custom characters from JSON array file as defined by constant CUSTOMCHARFILE
        # JSON format examplewith 2 characters: 
        # [
        #     {"id":0,"name":"battery","char":"14,27,17,17,17,17,17,31"},
        #     {"id":1,"name":"clock","char":"31,17,10,4,14,31,31,0"}
        # ]
        # Use exception handling in case file not found
        # The id must be in range 0-7 as max 8 custom characters can be defined

        if os.path.isfile(CUSTOMCHARFILE):
            try:
                with open(CUSTOMCHARFILE) as f:
                    json_char_array = json.load(f)
                    log("Customchar: #characters defined: {}".format(len(json_char_array)))
                    if len(json_char_array) > 0:
                        for item in json_char_array:
                            id = int(item["id"])
                            name = item["name"]
                            char = item["char"].split(",")  # split the char into list of str
                            char[:] = list(map(int, char))  # convert list str to int
                            log("Customchar: {},{},{}".format(id,name,char))
                            # Check if the character id is in range 0-7
                            if id >= 0 and id <= 7:
                                lcd.create_char(id, char)
                                log("Customchar: Index={},Name={},Char={}".format(id,name,item["char"]))
                            else:
                                return { "status" : STATUSERROR, "title" : "Customchar: Index={} not in range 0-7.".format(id) }
                    else:
                        return { "status" : STATUSERROR, "title" : "Customchar: No or wrong characters defined." }
                    log("Customchar = done")
            except Exception as e:
                return { "status" : STATUSERROR, "title" : "Customchar: {} - {}".format(CUSTOMCHARFILE, str(e)) }

        # Backlight setting must be done after create custom char
        if backlight == 1:
            lcd.backlight_on()
        else:
            lcd.backlight_off()
        log("backlight: {} = done".format(backlight))
    except Exception as e:
        return { "status" : STATUSERROR, "title" : MSGERRSETCONFIG + " - " + str(e)}
    log("set_configuration = done")
    return { "status" : STATUSOK, "title" : "Set Configuration."}

"""
Set LCD text for the 4 lines and 20 columns using json.
Parameter:
lcd - lcd device object
lines - json object holding up-to 4 lines
The JSON array has 1 to N entries with line properties.
It is possible to define an entry for a line or multiple entries for a line for different positions.
JSON keys with value explain
"line" - 1-4
"position" - 1-20
"clear": clear the display: 0=no clear, 1=clear line, 2=clear display
"text": text to display at the line

Example JSON string = JSON array for the 4 lines
jsonarraystring = '
[
    {"line":1,"position":1,"clear":1,"text":"TEXT 1"},
    {"line":2,"position":1,"clear":1,"text":"TEXT 2"},
    {"line":3,"position":1,"clear":1,"text":"TEXT 3"},
    {"line":4,"position":1,"clear":1,"text":"TEXT 4"}
]'
"""
def write_lines(lcd,lines):
    log("write_lines: text: {}".format(lines))
    result = "OK"
    EMPTYLINE = "                    "
    # Check if lines is none
    if lines is None:
        return { "status" : "ERROR", "title" : "LCD lines missing." }
    try:
        # Define the lcd function write_line parameter
        log("write_lines: parsing json ...")
        # the parameter lines is already a json array
        json_array = lines  # , encoding=None)
        log("write_lines: #lines: {}".format(len(json_array)))
        linecnt = 0
        for item in json_array:
            # line number
            line = 1
            if "line" in item:
                line = int(item["line"])
            log("Line:" + str(line))
            
            # column position
            position = 0
            if "position" in item:
                position = int(item["position"])

            text = ""
            if "text" in item:
                text = item["text"]

            # clear option
            clear = 0
            if "clear" in item:
                clear = int(item["clear"])
            log("line: items (l,p,t,c) {},{},{},{}".format(line,position,text,clear))

            # Checks
            if (line < 1 or line > 4):
                return { "status" : STATUSERROR, "title" : "Write line: Wrong line number: %d. Ensure 1-4." % (line)}
            if (position < 1 or position > 20):
                return { "status" : STATUSERROR, "title" : "Write line: Wrong position number: %d. Ensure 1-20." % (position)}
            # Adjust line to 0-3 and position 0-19
            line = line - 1
            position = position - 1

            # Clear action: 1=clear line;2=clear display (an also be done via key "CLEAR":1)
            if clear == 1:
                lcd.display_string(EMPTYLINE, line, 0)
            if clear == 2:
                lcd.clear()

            # Write text 
            lcd.display_string(text, line, position)
            linecnt = linecnt + 1
            log("write_lines: L={},P={},T={}".format(line,position,text))
        return { "status" : STATUSOK, "title" : "Lines written #{}".format(linecnt)}
    except Exception as e:
        return { "status" : STATUSERROR, "title" : "write_lines: Failed writing text {}".format(str(e)) }

if __name__ == "__main__":
    log("START")
    status = 1
    # Get the command line argurments
    # log("Arguments {}: {}".format(len(sys.argv), str(sys.argv)))
    if len(sys.argv) == ARGVLEN:
        # Parse the command line argument 1 from string to json 
        # Argument 1 must be a JSON string.
        # Example single line: '{"address":"0x27", "lcdlines":[{"line":1,"position":1,"clear":1,"text":"Text"}]}'
        args = json.loads(sys.argv[1])
        if KEYADDRESS in args:
            ADDRESS = args[KEYADDRESS]
        if KEYBACKLIGHT in args:
            BACKLIGHT = 1 if int(args[KEYBACKLIGHT]) == 1 else 0
        if KEYCURSOR in args:
            CURSOR = 1 if int(args[KEYCURSOR]) == 1 else 0
        if KEYBLINKING in args:
            BLINKING = 1 if int(args[KEYBLINKING]) == 1 else 0
        if KEYCLEAR in args:
            CLEAR = 1 if int(args[KEYCLEAR]) == 1 else 0
        if KEYDEBUG in args:
            DEBUG = 1 if int(args[KEYDEBUG]) == 1 else 0
        if KEYLCDLINES in args:
            LCDLINES = args[KEYLCDLINES]
        # Check the json parse result
        log("JSON:A={},B={},C={},BL={},CL={},L={}".format(ADDRESS,BACKLIGHT,CURSOR,BLINKING,CLEAR,LCDLINES))
    else:
        status = 0
        result = { "status" : STATUSERROR, "title" : "Wrong number of arguments. Use python3 lcdi2ccontrol.py parameter" }

    if status == 1:
        try:
            # Create LCD object
            log("Creating LCD Object:A={},L={},C={},CL={}".format(ADDRESS,LINES,COLS,CLEAR))
            lcd = lcdi2clib.lcd(int(ADDRESS, 16), LINES, COLS, CLEAR)
            log("Creating LCD Object = done")
            # Clear display = NOT USED as handled by key CLEAR
            # lcd.clear()
            log("LCD clear = done")
            # Set the config
            result = set_configuration(lcd,BACKLIGHT,CURSOR,BLINKING,CLEAR)
            log("set_configuration result: {}".format(result))
            # If config ok, write lines
            if result['status'] == STATUSOK:
                # Write the lines
                # log("LCDLINES: {}" + LCDLINES)
                if LCDLINES != None:
                    result = write_lines(lcd,LCDLINES)
        except Exception as e:
            result = { "status" : STATUSERROR, "title" : "LCD update failed:" + str(e) }
    # Print the result which is used by the dzVents Lua script
    print(json.dumps(result))
 