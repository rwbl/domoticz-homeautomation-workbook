# Changelog domoticz-home-automation-workbook - web ui quick access mobile
Customized web frontend to control dedicated functions mainly accessed from mobile smartphones devices.

### 20201020
* FIX: Corrected selector id for thermostatstate
* UPD: Code optimized (vars, comments)

### 20201001
* UPD: Select drop down arrow changed to black and bigger size

### 20200912
* NEW: First version published
