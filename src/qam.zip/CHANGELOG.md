# Changelog domoticz-home-automation-workbook - web ui quick access mobile
Customized web frontend to control dedicated functions mainly accessed from mobile smartphones devices.

### 20201001
* UPD: Select drop down arrow changed to black and bigger size

### 20200912
* NEW: First version published
