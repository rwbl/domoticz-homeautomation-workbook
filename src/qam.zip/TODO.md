# ToDo domoticz_quick_access_mobile

### Checkout cors error 127.0.0.1

_Status_
Not started
 