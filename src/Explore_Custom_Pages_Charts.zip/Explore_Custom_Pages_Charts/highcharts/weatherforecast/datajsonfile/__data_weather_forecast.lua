-- Persistent Data
local multiRefObjects = {

} -- multiRefObjects
local obj1 = {
	["forecastLocation"] = "Arrecife,28.9630,-13.5477";
}
return obj1
